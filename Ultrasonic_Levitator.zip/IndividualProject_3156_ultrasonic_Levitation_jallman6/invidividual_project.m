Temperature = 227.15;
V=sqrt(1.4*8.314/0.02895)*sqrt(Temperature)
v=343.8; % speed of sound at 70 degrees F and 761 ft
f=39500; % frequency of transducer

lambda=v/f;
height_mm=lambda*1000;
height_In=height_mm/25.4;
% Speaker is about 0.4 inches tall in total, and the diaphram is about 0.2
% inches, therefore the distance must account for two speakers of 0.2 inches
% (~10.16 mm / 0.4 in) offset.
formatSpec = '\n Standing Waves are Multiples of%8.3f Millimeters or%8.3f Inches \n';
fprintf(formatSpec,height_mm,height_In)
% height between top speakers must have the distance mentioned above included
% into the calculated  multiple of standing waves
FourxSW=4*height_In % Four times the standing wave distance 
% (should give a distance that is four standing waves/nodes from the speakers 

alpha=1.64; % Attenuation coefficient of air at 20*C
Z=[0:1000]./1000; % attenuation matrix for distances up to one meter

% Amplitude decay as distance increases, unfortunately there were no
% documents found that included the standard amplitude of the waves
% produced, so it is assumed an amplitude of "1" to display how as the
% distance between the speakers increases, the amplitude of the wave
% decreases, thus a reduction in power/levitation capability

Att=(exp(-alpha*Z))/0.1151;

plot(Z,Att)
xlabel('m')
ylabel('decibels')
axis([min(Z) max(Z) min(Att) max(Att)])
grid